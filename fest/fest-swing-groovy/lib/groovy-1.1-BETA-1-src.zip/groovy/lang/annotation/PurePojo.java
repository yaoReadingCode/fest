package groovy.lang.annotation;

public class PurePojo {
}
