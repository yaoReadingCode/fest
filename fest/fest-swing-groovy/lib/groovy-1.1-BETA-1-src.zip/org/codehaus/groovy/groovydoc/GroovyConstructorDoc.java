package org.codehaus.groovy.groovydoc;

public interface GroovyConstructorDoc extends GroovyExecutableMemberDoc {
}
